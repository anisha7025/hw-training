import scrapy

class UltaSpider(scrapy.Spider):
    name = 'ulta'
    allowed_domains = ['ulta.com']

    def start_requests(self):
        urls = ["https://www.ulta.com/p/coco-mademoiselle-eau-de-parfum-spray-pimprod2015831",
               "https://www.ulta.com/p/miss-dior-eau-de-parfum-xlsImpprod16711021",
               "https://www.ulta.com/p/cashmere-mist-deodorant-fs748724",
               "https://www.ulta.com/p/light-blue-eau-de-toilette-VP11736",
               "https://www.ulta.com/p/cloud-eau-de-parfum-pimprod2000100",
               "https://www.ulta.com/p/black-opium-eau-de-parfum-xlsImpprod12951153"]

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept - encoding': 'gzip, deflate, br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.101 Safari/537.36'
        }

        for url in urls:
            yield scrapy.Request(url, headers=headers)

    def parse(self, response):

        # EXTRACT
        url = response.url
        name = response.xpath('//div[@class="ProductMainSection__productName"]/span/text()').extract_first()
        brand = response.xpath('//div[@class="ProductMainSection__brandName"]/a/p/text()').extract_first()
        price = response.xpath('//div[@class="ProductPricingPanel"]/span/text()').extract_first()
        size = response.xpath('//div[@class="ProductSwatchImage__variantHolder"]//span/text()').extract()
        description = response.xpath('//div[@class="ProductDetail__productContent"]//text()').extract()
        image = response.xpath('//head//meta[@property="og:image"]/@content').extract_first()

        # CLEAN
        description = ''.join(description)


        item = {}
        item['product_url'] = url
        item['product_name'] = name
        item['brand_name'] = brand
        item['price'] = price
        item['currency'] = "USD"
        item['size'] = size
        item['description'] = description
        item['image_url'] = image

        yield item











