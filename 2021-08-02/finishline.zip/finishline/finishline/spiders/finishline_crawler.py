import scrapy
from scrapy.http import Request
from scrapy.exceptions import CloseSpider
from ..items import FinishlineUrlItem


headers = {
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,'
              '*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept - encoding': 'gzip, deflate, br',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
                  'Chrome/91.0.4472.101 Safari/537.36 '

}

class FinishlineCrawlerSpider(scrapy.Spider):
    name = 'finishline_crawler'
    allowed_domains = ['finishline.com']
    base_urls = 'https://www.finishline.com'

    def start_requests(self):
        urls = 'https://www.finishline.com/store/men/shoes/casual/_/N-1q3xsyk?icid=LP_mgl_C_menslpcategorycasualshoes_PDCT'
        yield Request(urls, callback=self.parse, headers=headers)

    def parse(self, response):

        links = response.xpath('//div[@class="product-card__details"]//a[@class="hover-underline"]/@href').extract()
        for link in links:
            url = self.base_urls + link

            item = FinishlineUrlItem()
            item['url'] = url
        
            yield item
        try:
            NEXT_PAGE_XPATH = '//a[contains(@class,"pag-button next")]/@href'
            next_page = response.xpath(NEXT_PAGE_XPATH).extract_first()
            new_page = self.base_urls + next_page
            if new_page:
                yield Request(new_page, headers=headers, callback=self.parse)
        except:
            raise CloseSpider('Crawling Completed')
