import scrapy
from scrapy.http import Request
from ..items import FinishlineItem

class FinishlineParseSpider(scrapy.Spider):
    name = 'finishline_parse'
    allowed_domains = ['finishline.com']

    def start_requests(self):

        urls = ['https://www.finishline.com/store/product/mens-nike-air-max-270-casual-shoes/prod2770900?styleId=AH8050&colorId=100',
        'https://www.finishline.com/store/product/mens-nike-air-force-1-07-casual-shoes/prod2767626?styleId=CT2302&colorId=002'
        ]

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,'
                      '*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept - encoding': 'gzip, deflate, br',
            'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/91.0.4472.101 Safari/537.36 '
        }
 
        for url in urls:
            yield Request(url, headers=headers)


    def parse(self, response):

        # Xpath
        url = response.url
        name = response.xpath('//h1/text()').extract_first()
        price = response.xpath('//span[@class="fullPrice"]/text()').extract_first()
        colors = response.xpath('//span[@class="description"]/text()').extract()
        sizes = response.xpath('//div[@id="alternateSizes"]//button[@data-size]/text()').extract()
        image_url = response.xpath('//div[@class="thumbSlide"]//img/@data-thumbsrc').extract_first()
        description = response.xpath('//div[@id="productDescription"]//text()').extract()

        # Clean
        name = name.strip()
        colors = [color.strip() for color in colors]
        nsize=[]
        [nsize.append(size) for size in sizes if size not in nsize]
        nsize=[i.strip() for i in nsize]
        description = [i.strip() for i in description]
        description = ''.join(description)


        item = FinishlineItem()
        item['product_url'] = url
        item['product_name'] = name
        item['price'] = price
        item['color'] = colors
        item['size'] = nsize
        item['image_url'] = image_url
        item['description'] = description

        yield item